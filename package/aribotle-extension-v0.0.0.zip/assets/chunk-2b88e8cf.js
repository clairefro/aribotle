console.info("chrome-ext template-react-js background script");chrome.runtime.onMessage.addListener(function(e,o,s){console.log("background script received message"),console.log({message:e})});
